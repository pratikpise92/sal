create database salary_manager;
use salary_manager;

/*
Navicat MySQL Data Transfer

Source Server         : MySQL
Source Server Version : 50520
Source Host           : localhost:3306
Source Database       : salary_manager

Target Server Type    : MYSQL
Target Server Version : 50520
File Encoding         : 65001

Date: 2014-04-06 18:45:35
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `attendence`
-- ----------------------------
DROP TABLE IF EXISTS `attendence`;
CREATE TABLE `attendence` (
  `Emp_ID` varchar(10) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Attend` int(1) DEFAULT NULL,
  `ADate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of attendence
-- ----------------------------

-- ----------------------------
-- Table structure for `dbautomate`
-- ----------------------------
DROP TABLE IF EXISTS `dbautomate`;
CREATE TABLE `dbautomate` (
  `swith` varchar(5) NOT NULL,
  `mpath` text CHARACTER SET utf8 NOT NULL,
  `dbname` text CHARACTER SET utf8 NOT NULL,
  `dbpath` text CHARACTER SET utf8 NOT NULL,
  `btime` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of dbautomate
-- ----------------------------
INSERT INTO `dbautomate` VALUES ('on', 'C:^wamp^bin^mysql^mysql5.5.20^bin', 'salary_manager', 'C:^backup^', '60');

-- ----------------------------
-- Table structure for `emploan`
-- ----------------------------
DROP TABLE IF EXISTS `emploan`;
CREATE TABLE `emploan` (
  `loanno` int(10) NOT NULL AUTO_INCREMENT,
  `EmpID` varchar(15) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `ldate` date DEFAULT NULL,
  `pl` char(255) DEFAULT NULL,
  PRIMARY KEY (`loanno`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of emploan
-- ----------------------------

-- ----------------------------
-- Table structure for `emploansummery`
-- ----------------------------
DROP TABLE IF EXISTS `emploansummery`;
CREATE TABLE `emploansummery` (
  `EmpID` varchar(15) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `ldate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of emploansummery
-- ----------------------------

-- ----------------------------
-- Table structure for `employee`
-- ----------------------------
DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `Emp_ID` varchar(10) NOT NULL,
  `FName` varchar(45) DEFAULT NULL,
  `LName` varchar(45) DEFAULT NULL,
  `Gender` varchar(45) DEFAULT NULL,
  `Mobile` varchar(11) DEFAULT NULL,
  `AccNo` varchar(11) DEFAULT NULL,
  `NIC` varchar(45) DEFAULT NULL,
  `No` varchar(45) DEFAULT NULL,
  `Street` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `JDate` date DEFAULT NULL,
  `Eps` char(1) DEFAULT NULL,
  `Epsno` varchar(10) DEFAULT NULL,
  `active` varchar(1) DEFAULT NULL,
  `Bsalary` double DEFAULT NULL,
  `emptype` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of employee
-- ----------------------------

-- ----------------------------
-- Table structure for `employeesr`
-- ----------------------------
DROP TABLE IF EXISTS `employeesr`;
CREATE TABLE `employeesr` (
  `Emp_ID` varchar(10) NOT NULL,
  `SR` varchar(200) DEFAULT NULL,
  `sdate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of employeesr
-- ----------------------------

-- ----------------------------
-- Table structure for `employee_other_payment`
-- ----------------------------
DROP TABLE IF EXISTS `employee_other_payment`;
CREATE TABLE `employee_other_payment` (
  `pno` int(11) NOT NULL,
  `Emp_ID` varchar(10) NOT NULL,
  `Emp_Name` varchar(200) NOT NULL,
  `Reason` varchar(40) NOT NULL,
  `PAmount` double NOT NULL,
  `Tdate` date NOT NULL,
  `WP` char(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of employee_other_payment
-- ----------------------------

-- ----------------------------
-- Table structure for `employee_salary_scheme`
-- ----------------------------
DROP TABLE IF EXISTS `employee_salary_scheme`;
CREATE TABLE `employee_salary_scheme` (
  `Emp_ID` varchar(10) NOT NULL,
  `Emp_Name` varchar(200) NOT NULL,
  `Pmode` varchar(30) NOT NULL,
  `PAmount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of employee_salary_scheme
-- ----------------------------

-- ----------------------------
-- Table structure for `login`
-- ----------------------------
DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `UserID` int(11) NOT NULL,
  `UName` varchar(45) DEFAULT NULL,
  `PWord` varchar(45) DEFAULT NULL,
  `UType` varchar(45) DEFAULT NULL,
  `AddEmp` varchar(10) DEFAULT NULL,
  `AddSup` varchar(45) DEFAULT NULL,
  `AddVehi` varchar(45) DEFAULT NULL,
  `AddFood` varchar(45) DEFAULT NULL,
  `AddRoute` varchar(45) DEFAULT NULL,
  `AddBankAcc` varchar(45) DEFAULT NULL,
  `AddCBook` varchar(45) DEFAULT NULL,
  `ViewSuppay` varchar(45) DEFAULT NULL,
  `PaySuppay` varchar(45) DEFAULT NULL,
  `Dailysale` varchar(45) DEFAULT NULL,
  `ViewBBanch` varchar(45) DEFAULT NULL,
  `Stockupdate` varchar(45) DEFAULT NULL,
  `ViewStock` varchar(45) DEFAULT NULL,
  `AddItemStock` varchar(45) DEFAULT NULL,
  `IssueStock` varchar(45) DEFAULT NULL,
  `Backup` varchar(45) DEFAULT NULL,
  `Resorte` varchar(45) DEFAULT NULL,
  `AddUser` varchar(45) DEFAULT NULL,
  `ChangeUP` varchar(45) DEFAULT NULL,
  `ViewUser` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of login
-- ----------------------------
INSERT INTO `login` VALUES ('1', 'admin', 'abc@123', 'Super Administrator', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true');

-- ----------------------------
-- Table structure for `paysheet`
-- ----------------------------
DROP TABLE IF EXISTS `paysheet`;
CREATE TABLE `paysheet` (
  `pno` int(11) NOT NULL,
  `Emp_ID` varchar(10) NOT NULL,
  `Emp_Name` varchar(200) NOT NULL,
  `baamount` double NOT NULL,
  `damount` double NOT NULL,
  `CEPF` double NOT NULL,
  `CETF` double NOT NULL,
  `nsalary` double NOT NULL,
  `year` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `noatt` varchar(3) DEFAULT NULL,
  `EEPF` double DEFAULT NULL,
  `Accno` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of paysheet
-- ----------------------------

-- ----------------------------
-- Table structure for `rate`
-- ----------------------------
DROP TABLE IF EXISTS `rate`;
CREATE TABLE `rate` (
  `cepf` double DEFAULT NULL,
  `cetf` double DEFAULT NULL,
  `eepf` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of rate
-- ----------------------------

-- ----------------------------
-- Table structure for `sdm`
-- ----------------------------
DROP TABLE IF EXISTS `sdm`;
CREATE TABLE `sdm` (
  `BID` varchar(10) NOT NULL,
  `SDName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`BID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of sdm
-- ----------------------------

-- ----------------------------
-- Table structure for `spm`
-- ----------------------------
DROP TABLE IF EXISTS `spm`;
CREATE TABLE `spm` (
  `BID` varchar(10) NOT NULL,
  `SPName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`BID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of spm
-- ----------------------------

-- ----------------------------
-- Table structure for `ssp`
-- ----------------------------
DROP TABLE IF EXISTS `ssp`;
CREATE TABLE `ssp` (
  `BID` varchar(10) NOT NULL,
  `SDName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`BID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of ssp
-- ----------------------------

-- ----------------------------
-- Table structure for `suptype`
-- ----------------------------
DROP TABLE IF EXISTS `suptype`;
CREATE TABLE `suptype` (
  `TypeID` int(11) NOT NULL,
  `Type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`TypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of suptype
-- ----------------------------
