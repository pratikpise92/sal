/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;
 
import GUI.DB;
import GUI.DB;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Vector;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import net.java.balloontip.BalloonTip;
import net.java.balloontip.utils.FadingUtils;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/**
 *
 * @author Jayawickrama
 */
public class salary_deduction_loan extends javax.swing.JFrame {
    private DefaultTableModel dtm;

    /**
     * Creates new form Vehicle_Expence
     */
    public salary_deduction_loan() {
        initComponents();
        makecenter();
        seticon();
        autoGRNno();
        jButton2.setEnabled(false);
        AutoCompleteDecorator.decorate(this.jComboBox1);
        AutoCompleteDecorator.decorate(this.jComboBox2);
  
      EID();
      EFname();
        
        jTextField4.setHorizontalAlignment(jTextField4.RIGHT);
        jTextField5.setHorizontalAlignment(jTextField5.RIGHT);
        alignRightt(jTable1, 3);
        alignCenter(jTable1, 4);
    }
     DecimalFormat df = new DecimalFormat("0.00");
     public  void EFname() {
        try {
            Connection con = DB.connect();
            ResultSet r = con.createStatement().executeQuery("select FName from employee where active='"+"Y"+"' ");
           
           jComboBox3.removeAllItems();
            while (r.next()) {
                String b = r.getString("FName");
        
                jComboBox3.addItem(b);
                
           
            }


        } catch (Exception ex) {
            ex.printStackTrace();
        }}
  void makecenter() {
        //create the frame  
        //make frame center   
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int framewidth = this.getSize().width;//get the width of the frame  
        int frameheigth = this.getSize().height; //get the heigth of the frame  
        int framelocationX = (dim.width - framewidth) / 2;
        int framelocationY = (dim.height - frameheigth) / 2;
        this.setLocation(framelocationX, framelocationY);
        //end of entering  
    }
 private  void seticon() {
      setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
    }
 
 
 
       private void alignCenter(JTable table, int column) {
    DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
    rightRenderer.setHorizontalAlignment(JLabel.CENTER);
    table.getColumnModel().getColumn(column).setCellRenderer(rightRenderer);
}
         private void alignRightt(JTable table, int column) {
    DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
    rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
    table.getColumnModel().getColumn(column).setCellRenderer(rightRenderer);
}   
 
  
   public  void EID() {
        try {
            Connection con = DB.connect();
            ResultSet r = con.createStatement().executeQuery("select Emp_ID from employee where active='"+"Y"+"' ");
           
           jComboBox2.removeAllItems();
            while (r.next()) {
                String b = r.getString("Emp_ID");
        
                jComboBox2.addItem(b);
                
           
            }


        } catch (Exception ex) {
            ex.printStackTrace();
        }}
   public  void Empdetails() {
        try {
            Connection con = DB.connect();
            ResultSet r = con.createStatement().executeQuery("select * from employee where active='"+"Y"+"' and Emp_ID='"+jComboBox2.getSelectedItem()+"'");
           
           
            while (r.next()) { 
                jTextField6.setText(  r.getString("FName")+" "+r.getString("LName")  );
               
           
            }

             ResultSet r1 = con.createStatement().executeQuery("select * from emploansummery where  EmpID  ='"+jComboBox2.getSelectedItem()+ "' ");
          boolean  b =false;
          double lamount=0.0;   
          while (r1.next()) {
                 b=true;
          lamount=Double.parseDouble(r1.getString("amount") );             
          }
             
             if(b){
                jTextField7.setText(lamount+"");
             }
                 else{
                 jTextField7.setText("0.00" );
                 }
             
             jTextField4.setText("" );
             jTextField8.setText("" );
        } catch (Exception ex) {
            ex.printStackTrace();
        }}
  
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        dateChooserCombo1 = new datechooser.beans.DateChooserCombo();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jTextField6 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jComboBox2 = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Advance and other payment to employee");
        setResizable(false);

        jTable1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Emp _ID", "Emp: Name", "Reason", "Amount", "Transaction Date", "due amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);
        jTable1.getColumnModel().getColumn(0).setResizable(false);
        jTable1.getColumnModel().getColumn(0).setPreferredWidth(15);
        jTable1.getColumnModel().getColumn(1).setResizable(false);
        jTable1.getColumnModel().getColumn(1).setPreferredWidth(70);
        jTable1.getColumnModel().getColumn(2).setResizable(false);
        jTable1.getColumnModel().getColumn(2).setPreferredWidth(80);
        jTable1.getColumnModel().getColumn(3).setResizable(false);
        jTable1.getColumnModel().getColumn(3).setPreferredWidth(20);
        jTable1.getColumnModel().getColumn(4).setResizable(false);
        jTable1.getColumnModel().getColumn(5).setResizable(false);

        jLabel1.setText("Payment  no:");

        jTextField1.setEnabled(false);

        jLabel2.setText("Today:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("Employee ID");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("Employee  Name");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("Reason");

        jTextField4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTextField4.setDisabledTextColor(new java.awt.Color(0, 51, 153));
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        jTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField4KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField4KeyReleased(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Total ");

        jTextField5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextField5.setDisabledTextColor(new java.awt.Color(204, 0, 102));
        jTextField5.setEnabled(false);

        jButton1.setText("Add to table");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGE/Save-icon.png"))); // NOI18N
        jButton2.setText("Save");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Delete row");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton6.setText("Close");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Reset all");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jTextField6.setEditable(false);
        jTextField6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTextField6.setDisabledTextColor(new java.awt.Color(0, 51, 204));
        jTextField6.setEnabled(false);
        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        jTextField6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField6KeyPressed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("Amount");

        jComboBox1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Loan instalment" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jComboBox2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText("Salary deduction loan instalment ");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("Employee Name:");

        jComboBox3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setText("Loan amount");

        jTextField7.setEditable(false);
        jTextField7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTextField7.setDisabledTextColor(new java.awt.Color(0, 51, 153));
        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });
        jTextField7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField7KeyPressed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setText("Loan due amount");

        jTextField8.setEditable(false);
        jTextField8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTextField8.setDisabledTextColor(new java.awt.Color(0, 51, 153));
        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        jTextField8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField8KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField6)
                                .addGap(14, 14, 14)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(112, 112, 112)
                                        .addComponent(jLabel4)))
                                .addGap(215, 215, 215)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(184, 184, 184)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 784, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addComponent(jLabel11)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dateChooserCombo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(138, 138, 138))
            .addGroup(layout.createSequentialGroup()
                .addGap(355, 355, 355)
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTextField1)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dateChooserCombo1, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel9))
                .addGap(4, 4, 4)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6))
                            .addComponent(jButton3)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton7))
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        
        
        
        item_addtotable();  
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      try {
            if(jTable1.getSelectedRow()>=0){
          DefaultTableModel dtm =(DefaultTableModel)jTable1.getModel();
             dtm.removeRow(jTable1.getSelectedRow());
             calculateTotalAmount();
            if(Double.parseDouble(jTextField5.getText())==0){
            jButton2.setEnabled(false);
            }
            
            }
            else{
            JOptionPane.showMessageDialog(null, "select raw first before delete");
            }
        } catch (Exception e) {
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
item_addtotable();        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jTextField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField4KeyPressed
     if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' ) {
             if(!(jTextField4.getText().contains("."))){
            jTextField4.setEditable(true);
             }
               
             if((jTextField4.getText().contains("."))&&(  jTextField4.getText().charAt((jTextField4.getText().length()-1) )=='.')){
               
                     jTextField4.setEditable(true);
                 
                }
             
             else  {
                 
                 if(jTextField4.getText().contains(".")&&(  jTextField4.getText().charAt((jTextField4.getText().length()-1) )!='.')){
                 
                 
             int a=jTextField4.getText().split("\\.")[1].length();
                if(a<2){
                    
                     jTextField4.setEditable(true);
                 
                }
               else{
               
                
              Toolkit.getDefaultToolkit().beep();
              BalloonTip balloonTip = new BalloonTip(jTextField4, "Numbers only");
              FadingUtils.fadeOutBalloon(balloonTip, null, 500,500);
              jTextField4.setEditable(false);
               }}
               
               
 
       
    }  
             
             
     //   jTextField4.setEditable(true);
      
    }
         
         
         
      else if(evt.getKeyChar() == '.' ){
        if(!(jTextField4.getText().contains("."))){
                           jTextField4.setEditable(true);    
         
        }else{
            jTextField4.setEditable(false);    
            
              Toolkit.getDefaultToolkit().beep();
              BalloonTip balloonTip = new BalloonTip(jTextField4, "Numbers only");
              FadingUtils.fadeOutBalloon(balloonTip, null, 500,500);
        }
           
    }
      
    else if(evt.getKeyCode()==KeyEvent.VK_BACK_SPACE){
        if(!jTextField4.getText().isEmpty()){
        String n =jTextField4.getText().substring(0, jTextField4.getText().length()-1); 
    jTextField4.setText(n);
    
        }
    }
     
      
    else {
        jTextField4.setEditable(false);
        
              Toolkit.getDefaultToolkit().beep();
              BalloonTip balloonTip = new BalloonTip(jTextField4, "Numbers only");
              FadingUtils.fadeOutBalloon(balloonTip, null, 500,500);
       
    }        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4KeyPressed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
   int c = JOptionPane.showConfirmDialog(null, "Are you sure  save Other payment to employee ? \nCheck wheather all are correcr before transfer", "Confirm save", JOptionPane.YES_NO_CANCEL_OPTION);
         if(c==0){
           
             try {
                   Connection con = DB.connect();
 
            


                      


            
            
            dtm = (DefaultTableModel) jTable1.getModel();
            //to get all Jtable sels in rows
            Object ob[] = new Object[6];
            int i = dtm.getRowCount();
             int pno=Integer.parseInt(jTextField1.getText());
            for (int a = 0; a < i; a++) {
                for (int b = 0; b <= 5; b++) {
                    ob[b] = dtm.getValueAt(a, b);
                }
               
                        
                try {
                   
                 
 PreparedStatement p = con.prepareStatement("insert into employee_other_payment values ('" +( pno++ ) + "','"+ ob[0] + "','" + ob[1] + "','" + ob[2] + "','" + ob[3] + "','" + ob[4]+ "','" + "W"+   "')");
                p.executeUpdate();
                p.close();

                PreparedStatement p1 = con.prepareStatement("insert into emploan (EmpID,amount,ldate,pl) values ('"  + ob[0]   + "','" + ob[3] + "','" + ob[4] + "','" + "P"+   "')");
                p1.executeUpdate();
                p1.close();
        
                PreparedStatement p3 = con.prepareStatement("update emploansummery set amount='"  +ob[5]  + "'where EmpID='"+ob[0]+   "'");
                p3.executeUpdate();
                p3.close();
        
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            
         } catch (Exception e) {
             }
        
          JOptionPane.showMessageDialog(null, "employee lpan received sucessfully saved"); 
         autoGRNno();
        
      
        jTextField4.setText("");
      
        jTextField8.setText("");
       
        
         jButton2.setEnabled(false);
      
                 Empdetails();
                   
          cleartable();
       
         }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
this.dispose();
new salary_deduction_loan().setVisible(true);
// TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField6KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField6KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6KeyPressed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
Empdetails();        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        loadOthersAccName();        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jTextField7KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField7KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7KeyPressed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jTextField8KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField8KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8KeyPressed

    private void jTextField4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField4KeyReleased
        try {
            double loan=Double.parseDouble(jTextField7.getText());
            double pay=Double.parseDouble(jTextField4.getText());
            double bal=loan-pay;
            if(bal>=0){
 jTextField8.setText(bal+"");
            }
            else{
Toolkit.getDefaultToolkit().beep();
              BalloonTip balloonTip = new BalloonTip(jTextField4, "Payment is greater than loan");
              FadingUtils.fadeOutBalloon(balloonTip, null, 500,800);
                jTextField8.setText("");
        jTextField4.setText("");
        }
        } catch (Exception e) {
            
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4KeyReleased

    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(salary_deduction_loan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(salary_deduction_loan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(salary_deduction_loan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(salary_deduction_loan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

                new salary_deduction_loan().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private datechooser.beans.DateChooserCombo dateChooserCombo1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private static javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JComboBox jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    // End of variables declaration//GEN-END:variables
private void loadOthersAccName() {
          try {
            Connection con = DB.connect();
            ResultSet r = con.createStatement().executeQuery("select * from employee where FName='"+jComboBox3.getSelectedItem()+"'");
           
           
            while (r.next()) { 
              
                jComboBox2.setSelectedItem(r.getString("Emp_ID")  );
               
            }
            Empdetails();

       
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    private void item_addtotable() {
        
        
        if(checktable()){
        JOptionPane.showMessageDialog(null, "Sorry!,This employee has already received,Delete that raw and again enter");
        }else{
        if(jComboBox1.getModel().equals("") || jTextField6.getText().isEmpty()|| jTextField4.getText().isEmpty() ){
//        JOptionPane.showMessageDialog(null, "Enter all field before enter to table");
 Toolkit.getDefaultToolkit().beep();
              BalloonTip balloonTip = new BalloonTip(jTextField4, "Enter all feild before enter");
              FadingUtils.fadeOutBalloon(balloonTip, null, 500,500);            
        }else{  
              DefaultTableModel dtm = (DefaultTableModel)jTable1.getModel();
             String fdate = dateChooserCombo1.getText();
            String senddate = null;
            String arry[] = fdate.split("/");
            senddate = "20"+arry[2] + "-" + arry[0] + "-" + arry[1];


                Vector v = new Vector();
                v.add(jComboBox2.getSelectedItem());
               
                 v.add(jTextField6.getText());
                 v.add(jComboBox1.getSelectedItem());
                 v.add(df.format(Double.parseDouble(jTextField4.getText())));
               v.add(senddate);
           v.add(df.format(Double.parseDouble(jTextField8.getText())));
         
            
          dtm.addRow(v);
          calculateTotalAmount();
         // jTextField3.setText(""); 
          jTextField4.setText("");
          jTextField8.setText("");
          
           
         jComboBox2.requestFocus();
          jButton2.setEnabled(true);
        }}}

 void calculateTotalAmount() {
DefaultTableModel dtm = (DefaultTableModel)jTable1.getModel();
     Object ob[]= new Object[5];
     int i = dtm.getRowCount();
    // System.out.println(i);
     double tot=0.0;
     for (int a = 0; a < i; a++) {
         for (int b = 0; b <= 4; b++) {
             ob[b]=dtm.getValueAt(a, b);
         }
        // System.out.println(ob[4].toString());
         tot+=Double.parseDouble(ob[3].toString());
        // System.out.println(tot);
     }

     jTextField5.setText(df.format(tot)+"");
  
   
    }
  void cleartable(){
       DefaultTableModel dtm = (DefaultTableModel) jTable1.getModel();
        int i = dtm.getRowCount();

        for (int a = 0; a < i; a++) {
        }
        while (i > 0) {
            dtm.removeRow(i - 1);

            i--;   
    }
    
    } 
  boolean checktable(){
       DefaultTableModel dtm = (DefaultTableModel) jTable1.getModel();
        int i = dtm.getRowCount();
       boolean checkid=false;
        for (int a = 0; a < i; a++) {
       Object eid=dtm.getValueAt(a, 0);
        if(jComboBox2.getSelectedItem().equals(eid)){
            checkid=true;
        
        }
        } 
    return  checkid;
    } 

    private void autoGRNno() {
        try {
            Connection con = DB.connect();
            ResultSet r = con.createStatement().executeQuery("select pno from employee_other_payment ");
            boolean b = false;
            String TypeID=null;
            while (r.next()) {
                TypeID = r.getString("pno");
                b= true;
            
            }
            if (b) {
                jTextField1.setText( Integer.parseInt(TypeID) + 1+""  );
            }
            else{
            jTextField1.setText( 1+"" );
            }
            
            
        } catch (Exception e) {
            e.printStackTrace();
        };
    }
  
}
