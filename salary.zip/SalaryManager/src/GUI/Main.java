/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Jayawickrama
 */
public class Main extends javax.swing.JFrame {
    public static String aswitch;
    private boolean loggoff =false;
    private Frame frame;

    /**
     * Creates new form Main
     */
    public Main() {
        initComponents();
        seticon();
       // setFullscree();
        loguser.setText(Login.loguser);
        type.setText(Login.type);
        settime();
        PrintToday();
        
        setptivillieage();
       
    }
void setptivillieage(){
    if("Operator".equals(Login.type)){

jMenu2.setEnabled(false);
jMenu4.setEnabled(false);
jMenu7.setEnabled(false);
jMenuItem10.setEnabled(false);
 
jMenuItem12.setEnabled(false);
jMenuItem13.setEnabled(false);
jMenuItem16.setEnabled(false);
jMenuItem17.setEnabled(false);
jMenuItem18.setEnabled(false);
jMenuItem19.setEnabled(false);

    }else{
    Autobackup();
    }



}
    private void seticon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
    }
    
    public void windowIconified(WindowEvent e) {
for (Frame f : JFrame.getFrames())
if (!f.equals(e.getWindow()))
f.setExtendedState(JFrame.ICONIFIED);
}
public void windowDeiconified(WindowEvent e) {
for (Frame f : JFrame.getFrames())
if (!f.equals(e.getWindow()))
f.setExtendedState(JFrame.NORMAL);
}

    public void setFullscree() {
// Dimension dim2 = (Toolkit.getDefaultToolkit()).getScreenSize();  
        //     setSize(dim2);  
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        //   setSize(WIDTH, HEIGHT);
        //setResizable(false);
    }

    void settime() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    Date d = new Date();
                    time.setText(d.toString().split(" ")[3]);

                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                    }
                }
            }
        }).start();
    }

    void PrintToday() { // method for print date on lable
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd ");
        Calendar cal = Calendar.getInstance();
        date.setText(dateFormat.format(cal.getTime()));

    }
    
    void logOff(){
    try {
       
            int a = JOptionPane.showConfirmDialog(null, "Do you really want to Log off", "Confirm Log off", JOptionPane.YES_NO_CANCEL_OPTION);
        if(a==0){ 
            loggoff=true;
            
        this.dispose();
        new Login().setVisible(true);
        }
        } catch (Exception e) {
        }
  
  }
void exit(){
                                   
        try {
            
            if(!loggoff){
            int a = JOptionPane.showConfirmDialog(null, "Do you really want to exit from  B.N.Salary Manager", "Confirm Exit", JOptionPane.YES_NO_CANCEL_OPTION);
        if(a==0){
        System.exit(0);      
        }}
        } catch (Exception e) {
        }
         

}


 public static void Autobackup(){
      
     try {
            
            
             Connection con1 = DB.connect();
                    ResultSet r = con1.createStatement().executeQuery("select * from dbAutomate");
                 boolean b= false;
        String      SdbNameBack = "";
        String SbackPath = "";
        String Smysqlpath = ""; 
            aswitch = "asd"; 
        double btime=0;
        
                 while (r.next()) {
                       b=true;
                     //    System.out.println("sdfdsfdsf");
                       aswitch=r.getString("swith");
                       SdbNameBack=r.getString("dbname");
                       SbackPath=r.getString("dbpath");
                       Smysqlpath=r.getString("mpath");
                       btime = Double.parseDouble(r.getString("btime"));
                        
                    }
              //   System.out.println(aswitch);
                  Main.loguser1.setText(aswitch);
                         
                 if(!b){
                 JOptionPane.showMessageDialog(null, "Authomated test does not execute, re test again"); 
                 }
                 
                 
                 if(aswitch.equals("on")){
                     
                     new Thread(new Runnable() {

            @Override
            public void run() {
                             try {
                                 Connection con1 = DB.connect();
                                  ResultSet r = con1.createStatement().executeQuery("select * from dbAutomate");
                               boolean b= false;
                      String      SdbNameBack = "";
                      String SbackPath = "";
                      
                       String fSbackPath = "";
                      String Smysqlpath = ""; 
                          String aswitch = ""; 
                      long btime=0;
                      int i = 0;
                               while (r.next()) {
                                     b=true;
                                     aswitch=r.getString("swith");
                                     SdbNameBack=r.getString("dbname");
                                     fSbackPath=r.getString("dbpath").replace('^' , '\\');;
                                     Smysqlpath=r.getString("mpath");
                                     btime = (long) Double.parseDouble(r.getString("btime"));
                                      
                                  }
                              
                          
                                 //System.out.println(SbackPath);
                              while (true) {
                                  
                                     SbackPath= fSbackPath+"auto_salary_manager@"+ new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss").format(new Date()) + ".sql";
                                 
                                  
                                         
                                boolean status = false;
                      String username = "root";
                      String password = "root";
                      String database = SdbNameBack;    //Database Name

                      String mysqldumpPath = Smysqlpath.replace('^' , '\\');
                                  //System.out.println(mysqldumpPath);
                      //MYSQL DUMPPATH location is changed if u using MYSQL5.5


                      String command = "/" + mysqldumpPath + "/mysqldump -u " + username + " -p" + password + " " + database + " -r " + SbackPath;
                      try {
                          Process runtimeProcess = Runtime.getRuntime().exec(command);
                          int processComplete = runtimeProcess.waitFor();
                          if (processComplete == 0) {
                             // System.out.println("DatabaseManager.backup: Backup Successfull");
                            //  JOptionPane.showMessageDialog(null, "DTF Successfull save file in " + SbackPath);
                                 Main.loguser1.setText(aswitch +"  last backup @ "+ new SimpleDateFormat("yyyy_MM_dd  hh:mm:ss").format(new Date())+".Automatically backp by "+btime+" min:");
                              status = true;
                            // SbackPath = "";
                           
                          } else {
                             // System.out.println("DatabaseManager.backup: Backup Failure!");
                              JOptionPane.showMessageDialog(null, "Backup Failure!");
                          }
                      } catch (IOException ioe) {
                          System.out.println("Exception IO");
                          JOptionPane.showMessageDialog(null, "I/O Error  " + ioe);
                          ioe.printStackTrace();
                      } catch (Exception e) {
                          System.out.println("Exception");
                          JOptionPane.showMessageDialog(null, "Error  " + e);
                          e.printStackTrace();
                      }
                   //   return status;
                    
                    
                    
                    
                    

                                  try {
                                      Thread.sleep(btime*60000);
                                  } catch (Exception e) {
                                  e.printStackTrace();
                                  }
                              }
                             } catch (Exception ex) {
                                 Logger.getLogger(Auto_DB_Backup.class.getName()).log(Level.SEVERE, null, ex);
                             }
            }
        }).start(); 
                     
       }
            
        } catch (Exception e) {
        }
        
    
    
    
    
    
    } 











    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Log_pane = new javax.swing.JPanel();
        type = new javax.swing.JLabel();
        loguser = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        time = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        Log_pane1 = new javax.swing.JPanel();
        loguser1 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem14 = new javax.swing.JMenuItem();
        jMenuItem15 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        jMenuItem18 = new javax.swing.JMenuItem();
        jMenuItem13 = new javax.swing.JMenuItem();
        jMenuItem16 = new javax.swing.JMenuItem();
        jMenuItem17 = new javax.swing.JMenuItem();
        jMenuItem19 = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenuItem20 = new javax.swing.JMenuItem();
        jMenuItem21 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();

        jLabel7.setText("jLabel7");

        jLabel8.setText("jLabel8");

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jDialog1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(140, 140, 140))
            .addGroup(jDialog1Layout.createSequentialGroup()
                .addGap(145, 145, 145)
                .addComponent(jLabel8)
                .addContainerGap(221, Short.MAX_VALUE))
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel7)
                .addGap(83, 83, 83)
                .addComponent(jLabel8)
                .addContainerGap(152, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("B.N. Salary Manager ");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                close(evt);
            }
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closing(evt);
            }
            public void windowDeiconified(java.awt.event.WindowEvent evt) {
                minimize(evt);
            }
            public void windowIconified(java.awt.event.WindowEvent evt) {
                minimizee(evt);
            }
        });
        getContentPane().setLayout(null);

        Log_pane.setBackground(new java.awt.Color(204, 255, 204));
        Log_pane.setBorder(javax.swing.BorderFactory.createTitledBorder("   loging  information"));

        type.setText("type");

        loguser.setText("loguser");

        jLabel5.setText("loging as");

        jLabel4.setText("You are ");

        time.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        time.setText("time");

        date.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        date.setText("date");

        javax.swing.GroupLayout Log_paneLayout = new javax.swing.GroupLayout(Log_pane);
        Log_pane.setLayout(Log_paneLayout);
        Log_paneLayout.setHorizontalGroup(
            Log_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Log_paneLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(loguser)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(type)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(time)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(date)
                .addContainerGap(307, Short.MAX_VALUE))
        );
        Log_paneLayout.setVerticalGroup(
            Log_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Log_paneLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Log_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(type)
                    .addComponent(loguser)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(time, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        getContentPane().add(Log_pane);
        Log_pane.setBounds(20, 80, 570, 48);

        Log_pane1.setBackground(new java.awt.Color(204, 255, 204));
        Log_pane1.setBorder(javax.swing.BorderFactory.createTitledBorder("   Auto Backup  information"));

        loguser1.setForeground(new java.awt.Color(0, 102, 255));
        loguser1.setText("loguser");

        jLabel53.setText("Auto backup is ");

        javax.swing.GroupLayout Log_pane1Layout = new javax.swing.GroupLayout(Log_pane1);
        Log_pane1.setLayout(Log_pane1Layout);
        Log_pane1Layout.setHorizontalGroup(
            Log_pane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Log_pane1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel53)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loguser1)
                .addContainerGap(434, Short.MAX_VALUE))
        );
        Log_pane1Layout.setVerticalGroup(
            Log_pane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Log_pane1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Log_pane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(loguser1)
                    .addComponent(jLabel53)))
        );

        getContentPane().add(Log_pane1);
        Log_pane1.setBounds(20, 30, 570, 48);

        jLabel64.setFont(new java.awt.Font("Tw Cen MT", 0, 48)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(0, 0, 51));
        jLabel64.setText("Salary Manager");
        getContentPane().add(jLabel64);
        jLabel64.setBounds(262, 250, 320, 66);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGE/login_origial.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(-80, 100, 870, 330);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGE/login_origial.jpg"))); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(-230, -60, 870, 330);

        jMenuBar1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jMenu1.setText("File");

        jMenuItem1.setText("Log off");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Exit");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Manage");

        jMenuItem8.setText("Add Employee");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem8);

        jMenu6.setText("Report");

        jMenuItem14.setText("Daily attendence");
        jMenuItem14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem14ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem14);

        jMenuItem15.setText("Report to bank");
        jMenuItem15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem15ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem15);

        jMenu2.add(jMenu6);

        jMenuBar1.add(jMenu2);

        jMenu4.setText("System");

        jMenuItem4.setText("Backup");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem4);

        jMenuItem5.setText("Restore");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem5);

        jMenuItem6.setText("Auto Backup");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem6);

        jMenuItem7.setText("Add User");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem7);

        jMenuBar1.add(jMenu4);

        jMenu5.setText("Salary");

        jMenuItem9.setText("Daily attendence mark");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem9);

        jMenuItem10.setText("Update employee payment mode");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem10);

        jMenuItem11.setText("Advace Payment  & Other payment");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem11);

        jMenuItem12.setText("Bonus  & Excess Payment");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem12);

        jMenuItem18.setText("No pay tranaction");
        jMenuItem18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem18ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem18);

        jMenuItem13.setText("Pay Sheet");
        jMenuItem13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem13ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem13);

        jMenuItem16.setText("Update Error  Attendence");
        jMenuItem16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem16ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem16);

        jMenuItem17.setText("Delete  advance & bonus payment");
        jMenuItem17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem17ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem17);

        jMenuItem19.setText("Delete salary payment");
        jMenuItem19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem19ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem19);

        jMenuBar1.add(jMenu5);

        jMenu7.setText("Loan");

        jMenuItem20.setText("Loan issue");
        jMenuItem20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem20ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem20);

        jMenuItem21.setText("Loan receive");
        jMenuItem21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem21ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem21);

        jMenuBar1.add(jMenu7);

        jMenu3.setText("About");

        jMenuItem3.setText("About");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem3);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-629)/2, (screenSize.height-398)/2, 629, 398);
    }// </editor-fold>//GEN-END:initComponents

    private void minimize(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_minimize
 windowDeiconified(evt);        // TODO add your handling code here:
    }//GEN-LAST:event_minimize

    private void close(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_close
exit();        // TODO add your handling code here:
    }//GEN-LAST:event_close

    private void closing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closing
exit();        // TODO add your handling code here:
    }//GEN-LAST:event_closing

    private void minimizee(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_minimizee
 windowIconified(evt);
        // TODO add your handling code here:
    }//GEN-LAST:event_minimizee

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
exit();        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
       new GUI.About(frame, true).setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
     new DB_Backup().setVisible(true);
        DB_Backup.selectbackup(1);       // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
   new DB_Backup().setVisible(true);
        DB_Backup.selectbackup(0);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
new Auto_DB_Backup().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
new Create_New_User().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem7ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
logOff();        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
new Add_Employee().setVisible(true);       // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem9ActionPerformed
new Daily_attendence().setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem9ActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
new   Employee_salary_scheem().setVisible(true);      // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem10ActionPerformed

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem11ActionPerformed
new salary_deduction().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem11ActionPerformed

    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem12ActionPerformed
new salary_special_payment().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem12ActionPerformed

    private void jMenuItem13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem13ActionPerformed
new salary_pay_sheet().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem13ActionPerformed

    private void jMenuItem14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem14ActionPerformed
new report_daily_attendece().setVisible(true);          // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem14ActionPerformed

    private void jMenuItem15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem15ActionPerformed
new report_bank_salary().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem15ActionPerformed

    private void jMenuItem16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem16ActionPerformed
new    Daily_attendence_update().setVisible(true);     // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem16ActionPerformed

    private void jMenuItem17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem17ActionPerformed
new reverse_pay().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem17ActionPerformed

    private void jMenuItem18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem18ActionPerformed
new salary_deduction_nopay().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem18ActionPerformed

    private void jMenuItem19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem19ActionPerformed
new reverse_paysalary().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem19ActionPerformed

    private void jMenuItem21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem21ActionPerformed
new salary_deduction_loan().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem21ActionPerformed

    private void jMenuItem20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem20ActionPerformed
new loan_issue().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem20ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Log_pane;
    private javax.swing.JPanel Log_pane1;
    private javax.swing.JLabel date;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem13;
    private javax.swing.JMenuItem jMenuItem14;
    private javax.swing.JMenuItem jMenuItem15;
    private javax.swing.JMenuItem jMenuItem16;
    private javax.swing.JMenuItem jMenuItem17;
    private javax.swing.JMenuItem jMenuItem18;
    private javax.swing.JMenuItem jMenuItem19;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem20;
    private javax.swing.JMenuItem jMenuItem21;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JLabel loguser;
    public static javax.swing.JLabel loguser1;
    public static javax.swing.JLabel time;
    private javax.swing.JLabel type;
    // End of variables declaration//GEN-END:variables
}
