/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * DB_Backup.java
 *
 * Created on Oct 16, 2012, 2:03:10 PM
 */
package GUI;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import net.java.balloontip.BalloonTip;
import net.java.balloontip.utils.FadingUtils;

/**
 *
 * @author Anuja
 */
public class Auto_DB_Backup extends javax.swing.JFrame {

    static String unameBack, passBack, dbNameBack, mysqlpath, backPath,unameRe,passRe,dbNameRe,fileSPath;
     static boolean finish =false;
    private boolean filecorrect=false;
    private String bpathtosave;

    /** Creates new form DB_Backup */
    public Auto_DB_Backup() {
        initComponents();
        seticon();
        enableAccodinttoJbutton(false);
        btnBackup2.setEnabled(false);
      //  jLabel9.setText(Main.aswitch);
    }
  private  void seticon() {
      setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
    }
  
  
  
  void enableAccodinttoJbutton(boolean b){
  txtDBNameBackup.setEnabled(b);
  txtSelectBackupTo.setEnabled(b);
  jTextField1.setEnabled(b);
  btnBackup.setEnabled(b);
  btnBackup1.setEnabled(b);
  jButton1.setEnabled(b);
    btnBackupPath.setEnabled(b);  
    btnBackup2.setEnabled(!b);
  }
  
  
  
  
    void getStringsBackup() {
        unameBack = txtUserNameBackup.getText();
        passBack = passwordBackup.getText();
        dbNameBack = txtDBNameBackup.getText();
        backPath = txtSelectBackupTo.getText();
        mysqlpath = txtMySqlPath.getText(); 
    }
    //*********Backup code***********//

 
    public static boolean backup() {
        boolean status = false;
        String username = unameBack;
        String password = passBack;
        String database = dbNameBack;    //Database Name

        String mysqldumpPath = mysqlpath;
        //MYSQL DUMPPATH location is changed if u using MYSQL5.5


        String command = "/" + mysqldumpPath + "/mysqldump -u " + username + " -p" + password + " " + database + " -r " + backPath;
        try {
            Process runtimeProcess = Runtime.getRuntime().exec(command);
            int processComplete = runtimeProcess.waitFor();
            if (processComplete == 0) {
               // System.out.println("DatabaseManager.backup: Backup Successfull");
                JOptionPane.showMessageDialog(null, "DTF Successfull save file in " + backPath);
                status = true;
                finish=true;
            } else {
               // System.out.println("DatabaseManager.backup: Backup Failure!");
                JOptionPane.showMessageDialog(null, "Backup Failure!");
            }
        } catch (IOException ioe) {
            System.out.println("Exception IO");
            JOptionPane.showMessageDialog(null, "I/O Error  " + ioe);
            ioe.printStackTrace();
        } catch (Exception e) {
            System.out.println("Exception");
            JOptionPane.showMessageDialog(null, "Error  " + e);
            e.printStackTrace();
        }
        return status;
    }
    //********end Backup code********//
    
    

    void checkbackup(){
    String a[] =fileSPath.split("/"); 
        System.out.println(a[a.length]);
    String b[]= a[a.length].split("@");
    if(b[0].equals("bn")){
    filecorrect = true;
    }
    else {filecorrect=false;}
    }
    
    
    //*********Restore code***********//
public static boolean restore(){
    boolean status = false;
    String username = unameRe;
    String password = passRe;
    String database = dbNameBack;
   String filePath = fileSPath;  //GIVE SAVED BAKUP FILE PATH
   
   String mysqldumpPath = mysqlpath+"/mysql";
   
    String[] command = new String[]{mysqldumpPath , database , "-u" + username, "-p" + password, "-e", " source "+filePath };

    //Please Change C:/Program Files/MySQL/MySQL Server 5.1/bin/mysql link if u using MYSQL 5.5
    
    
    try {
        Process runtimeProcess = Runtime.getRuntime().exec(command);
        int processComplete = runtimeProcess.waitFor();
        if (processComplete == 0) {
          //  System.out.println("DatabaseManager.restore: Restore Successfull");
            JOptionPane.showMessageDialog(null, "DTF Uploded Successfully");
            status = true;
        } else {
            System.out.println("DatabaseManager.restore: Restore Failure!");
         JOptionPane.showMessageDialog(null, "DTF Failure!");
        }
    } catch (IOException ioe) {
        System.out.println("Exception IO");
        JOptionPane.showMessageDialog(null, "I/O Error  " +ioe);
        ioe.printStackTrace();
    } catch (Exception e) {
        System.out.println("Exception");
        JOptionPane.showMessageDialog(null, "Error  " +e);
        e.printStackTrace();
    }
    return status;
}  
    
    
    //*******end Restore code*********//
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtMySqlPath = new javax.swing.JTextField();
        btnSelectMySqlPath = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        txtDBNameBackup = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtSelectBackupTo = new javax.swing.JTextField();
        btnBackupPath = new javax.swing.JButton();
        btnBackup = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        txtUserNameBackup = new javax.swing.JTextField();
        passwordBackup = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        btnBackup1 = new javax.swing.JButton();
        btnBackup2 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("DB Backup");
        setResizable(false);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Set path and time ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14), new java.awt.Color(0, 204, 204))); // NOI18N

        jLabel1.setText("Select MySQL bin Path :");

        txtMySqlPath.setEditable(false);
        txtMySqlPath.setText("C:\\Program Files\\MySQL\\MySQL Server 5.1\\bin");
        txtMySqlPath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMySqlPathActionPerformed(evt);
            }
        });

        btnSelectMySqlPath.setText("Browse");
        btnSelectMySqlPath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectMySqlPathActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(153, 255, 153));

        jLabel5.setText("Database Name           :");

        txtDBNameBackup.setEditable(false);
        txtDBNameBackup.setText("salary_manager");

        jLabel6.setText("Backup Database to    :");

        txtSelectBackupTo.setEditable(false);

        btnBackupPath.setText("Browse");
        btnBackupPath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackupPathActionPerformed(evt);
            }
        });

        btnBackup.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnBackup.setText("Start Backup Database Automatically");
        btnBackup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackupActionPerformed(evt);
            }
        });

        jButton1.setText("Clear");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        txtUserNameBackup.setEditable(false);
        txtUserNameBackup.setBackground(new java.awt.Color(204, 204, 204));
        txtUserNameBackup.setForeground(new java.awt.Color(204, 204, 204));
        txtUserNameBackup.setText("root");

        passwordBackup.setEditable(false);
        passwordBackup.setBackground(new java.awt.Color(204, 204, 204));
        passwordBackup.setForeground(new java.awt.Color(204, 204, 204));
        passwordBackup.setText("root");
        passwordBackup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordBackupActionPerformed(evt);
            }
        });

        jLabel3.setText("Time                             :");

        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField1KeyPressed(evt);
            }
        });

        jLabel4.setText("( in Minutes )");

        jLabel7.setText("Automatic backup (on/off)    :");

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setText("On");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setText("Off");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });

        btnBackup1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnBackup1.setText("Test");
        btnBackup1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackup1ActionPerformed(evt);
            }
        });

        btnBackup2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnBackup2.setText("Stop Backup Database Automatically");
        btnBackup2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackup2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 6, Short.MAX_VALUE)
                        .addComponent(btnBackup2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnBackup1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnBackup))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(34, 34, 34)
                                .addComponent(jRadioButton1)
                                .addGap(18, 18, 18)
                                .addComponent(jRadioButton2))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel6)
                                            .addComponent(jLabel5))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(txtDBNameBackup, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(99, 99, 99)
                                                .addComponent(txtUserNameBackup, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(txtSelectBackupTo, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnBackupPath)))))
                                .addGap(18, 18, 18)
                                .addComponent(passwordBackup, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jRadioButton2)
                        .addComponent(jRadioButton1)))
                .addGap(5, 5, 5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtDBNameBackup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtSelectBackupTo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnBackupPath))))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtUserNameBackup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(passwordBackup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4)))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBackup, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBackup1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBackup2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(84, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Backup", jPanel2);

        jLabel11.setText("Eg:-     C:\\Program Files\\MySQL\\MySQL Server 5.1\\bin");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtMySqlPath, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSelectMySqlPath))
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtMySqlPath, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSelectMySqlPath))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("Automatically Backup Database");

        jButton3.setText("Close");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setText("Automatically backup is :");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 51, 102));
        jLabel9.setText("XX");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(190, 190, 190)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(30, 30, 30))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 12, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3)
                .addContainerGap())
        );

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-706)/2, (screenSize.height-463)/2, 706, 463);
    }// </editor-fold>//GEN-END:initComponents
void clearBackUp(){
    //txtUserNameBackup.setText("");
    //passwordBackup.setText("");
    //txtDBNameBackup.setText("");
    txtSelectBackupTo.setText("");
}
void clearRestore(){
    //txtUserNameRestore.setText("");
    //passwordRestore.setText("");
    //txtDBNameRestore.setText("");
//    txtSelectBackupFile.setText("");
}
private void btnSelectMySqlPathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelectMySqlPathActionPerformed

    JFileChooser chooser = new JFileChooser();
    chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
    int returnVal = chooser.showOpenDialog(this);
    if (returnVal == JFileChooser.APPROVE_OPTION) {
        txtMySqlPath.setText(chooser.getSelectedFile().getAbsolutePath());
    }
}//GEN-LAST:event_btnSelectMySqlPathActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtMySqlPathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMySqlPathActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMySqlPathActionPerformed

    private void passwordBackupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordBackupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordBackupActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        clearBackUp();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnBackupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackupActionPerformed

        
          int c = JOptionPane.showConfirmDialog(null, "Do you want to start backup auctomatically", "Confirm start backup automatically", JOptionPane.YES_NO_CANCEL_OPTION);
        if(c==0){
       Main.Autobackup();
        btnBackup.setEnabled(false);
        btnBackup1.setEnabled(false);
     jLabel9.setText(Main.aswitch);
        }
      
       
         else {
            JOptionPane.showMessageDialog(null, "Check all Fields");
        }
    }//GEN-LAST:event_btnBackupActionPerformed

    private void btnBackupPathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackupPathActionPerformed
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        int returnVal = chooser.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            txtSelectBackupTo.setText(chooser.getSelectedFile().getAbsolutePath()+ System.getProperty("file.separator") +"bn@"+ new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss").format(new Date()) + ".sql");
        
        bpathtosave=chooser.getSelectedFile().getAbsolutePath()+ System.getProperty("file.separator");
        }
    }//GEN-LAST:event_btnBackupPathActionPerformed

    private void btnBackup1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackup1ActionPerformed

        if(jTextField1.getText().isEmpty()){
        JOptionPane.showMessageDialog(null, "Enter time before test");
        
        }else{
        
        
                if (txtMySqlPath.getText().length() != 0 || txtUserNameBackup.getText().length() != 0 || passwordBackup.getText().length() != 0 || txtDBNameBackup.getText().length() != 0 || txtSelectBackupTo.getText().length() != 0) {
            getStringsBackup();
            backup();
          
            if(finish){
                try {
                    String s="";
                    if(jRadioButton1.isSelected()){
                    s="on";
                    }
                    else{
                    s="off";
                    }
                       Connection con = DB.connect();
                       
                      String  mpath=txtMySqlPath.getText().replace('\\' , '^');
                      String bpath=bpathtosave.replace('\\' , '^');
                //      System.out.println(mpath);    

            PreparedStatement p = con.prepareStatement("insert into dbAutomate values('" + s +"','"+ mpath +"','"+ txtDBNameBackup.getText() +"','"+bpath +"','"+Double.parseDouble(jTextField1.getText()) + "')");
           
            
           //  PreparedStatement p = con.prepareStatement("insert into studentDetail values ('" + jTextField2.getText() + "','" + jTextField3.getText() + "','" + jTextField4.getText() + "','" + jComboBox1.getSelectedItem() + "','" + jTextField5.getText() + "','" + jTextField6.getText() + "')");
            
            p.executeUpdate();
            p.close();
              clearBackUp();
            JOptionPane.showMessageDialog(null, "Save path and time sucessfully");
            btnBackup.setEnabled(true);
                    
                } catch (Exception e) {
                }
            
            }
        } else {
            JOptionPane.showMessageDialog(null, "Check all Fields");
        }
        
        
        
        
        
        
        
        }
        
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBackup1ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
enableAccodinttoJbutton(true);   

btnBackup.setEnabled(false);
// TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
enableAccodinttoJbutton(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyPressed
 if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' ) {
        jTextField1.setEditable(true);
      
    }
    else if(evt.getKeyCode()==KeyEvent.VK_BACK_SPACE){
        if(!jTextField1.getText().isEmpty()){
        String n =jTextField1.getText().substring(0, jTextField1.getText().length()-1); 
    jTextField1.setText(n);
    
        }
    }
      
    else {
        jTextField1.setEditable(false);
        
              Toolkit.getDefaultToolkit().beep();
              BalloonTip balloonTip = new BalloonTip(jTextField1, "Digits only");
              FadingUtils.fadeOutBalloon(balloonTip, null, 500,500);
    }        
 // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1KeyPressed

    private void btnBackup2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackup2ActionPerformed
   
          int c = JOptionPane.showConfirmDialog(null, "Do you want to stop backup auctomatically", "Confirm stop backup automatically", JOptionPane.YES_NO_CANCEL_OPTION);
        if(c==0){
            try {
                 Connection con = DB.connect();
                 PreparedStatement p = con.prepareStatement("update  dbAutomate set swith= '"+"off"+"'");
                 p.executeUpdate();
                 p.close();
                Main.Autobackup();
                  jLabel9.setText(Main.aswitch);
                 JOptionPane.showMessageDialog(null, "Auto backup stop sucessfully");
                 btnBackup2.setEnabled(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
              // TODO add your handling code here:
    }//GEN-LAST:event_btnBackup2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Auto_DB_Backup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Auto_DB_Backup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Auto_DB_Backup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Auto_DB_Backup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new Auto_DB_Backup().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackup;
    private javax.swing.JButton btnBackup1;
    private javax.swing.JButton btnBackup2;
    private javax.swing.JButton btnBackupPath;
    private javax.swing.JButton btnSelectMySqlPath;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private static javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField passwordBackup;
    private javax.swing.JTextField txtDBNameBackup;
    private javax.swing.JTextField txtMySqlPath;
    private javax.swing.JTextField txtSelectBackupTo;
    private javax.swing.JTextField txtUserNameBackup;
    // End of variables declaration//GEN-END:variables

    
   








}
