/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;
 
import GUI.DB;
import GUI.DB;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperPrintManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRTableModelDataSource;
import net.sf.jasperreports.view.JasperViewer;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;
import org.jvnet.substance.color.JadeForestColorScheme;

/**
 *
 * @author Jayawickrama
 */
public class salary_pay_sheet extends javax.swing.JFrame {
    private DefaultTableModel dtm;
    private String ESP;
    private DefaultTableModel dtm2;
    private DefaultTableModel dtm3;

    /**
     * Creates new form Vehicle_Expence
     */
    public salary_pay_sheet() {
        initComponents();
        makecenter();
        seticon();
        autoGRNno();
        jButton2.setEnabled(false);
        jButton8.setEnabled(false);
     loadrate();
        AutoCompleteDecorator.decorate(this.jComboBox2);
        AutoCompleteDecorator.decorate(this.jComboBox1);
       
      
         setstart();
        jTextField4.setHorizontalAlignment(jTextField4.RIGHT);
        jTextField5.setHorizontalAlignment(jTextField5.RIGHT);
        jTextField9.setHorizontalAlignment(jTextField9.RIGHT);
        jTextField3.setHorizontalAlignment(jTextField3.RIGHT);
        jTextField8.setHorizontalAlignment(jTextField8.RIGHT);
        jTextField5.setHorizontalAlignment(jTextField5.RIGHT);
        jTextField7.setHorizontalAlignment(jTextField7.RIGHT);
        
        alignRightt(jTable1, 1);
        alignRightt(jTable2, 1);
        
        dateChooserCombo2.setEnabled(true);
    }
     DecimalFormat df = new DecimalFormat("0.00");
  void makecenter() {
        //create the frame  
        //make frame center   
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int framewidth = this.getSize().width;//get the width of the frame  
        int frameheigth = this.getSize().height; //get the heigth of the frame  
        int framelocationX = (dim.width - framewidth) / 2;
        int framelocationY = (dim.height - frameheigth) / 2;
        this.setLocation(framelocationX, framelocationY);
        //end of entering  
    }
 private  void seticon() {
      setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
    }
 
 
 
static  void loadrate(){


    try {
          Connection con = DB.connect();
            
            
             ResultSet r2 = con.createStatement().executeQuery("select * from rate");
      
                while (r2.next()) {
                jTextField11.setText(r2.getString("cepf"));
                  jTextField13.setText(r2.getString("cetf"));
                    jTextField12.setText(r2.getString("eepf"));
                
                }
    } catch (Exception e) {
        e.printStackTrace();
    }




}
   void BasicTableLoad(){

 try {
     cleartable();
     
            Connection con = DB.connect();
            
            
             ResultSet r2 = con.createStatement().executeQuery("select Bsalary from employee where active='"+"Y"+"' and Emp_ID='"+jComboBox2.getSelectedItem()+"'");
      double basic=0;
 dtm = (DefaultTableModel) jTable1.getModel();
                while (r2.next()) {
                Vector v = new Vector();
                    
                    basic=Double.parseDouble(r2.getString("Bsalary"));
                        
                    
                v.add("Basic Salary");
                v.add(df.format(basic));
           dtm.addRow(v);
                }
            
            
            
            
            
            
            
            
      ResultSet r = con.createStatement().executeQuery("select * from employee_salary_scheme where   Emp_ID='"+jComboBox2.getSelectedItem()+"'");
    
 dtm = (DefaultTableModel) jTable1.getModel();
                while (r.next()) {
                Vector v = new Vector();
                  
                v.add(r.getString("Pmode"));
                v.add(df.format(Double.parseDouble(r.getString("PAmount"))*Double.parseDouble(jTextField4.getText())));
           dtm.addRow(v);
                }
      
                
                String sdate=jTextField2.getText().split(" to ")[0];
            String edate=jTextField2.getText().split(" to ")[1];
      ResultSet r1 = con.createStatement().executeQuery("select Reason,SUM(PAmount) as PAmount from employee_other_payment where Emp_ID='"+jComboBox2.getSelectedItem()+"'and WP='"+"P"+"'and Tdate between'"+sdate+"'and'"+edate+"' group by Reason ");
  
 dtm = (DefaultTableModel) jTable1.getModel();
                while (r1.next()) {
                Vector v = new Vector();
                v.add(r1.getString("Reason"));
               
                v.add(df.format(Double.parseDouble(r1.getString("PAmount") )));
           dtm.addRow(v);
                }
                 
                if("Y".equals(ESP) ){
                     double eps=basic *Double.parseDouble(jTextField11.getText())*0.01 ;
                     double ets=basic * Double.parseDouble(jTextField12.getText())*0.01;
                     double empets=basic * Double.parseDouble(jTextField13.getText())*0.01;
                   
                    jTextField3.setText(df.format(eps));
                    jTextField8.setText(df.format(ets));
                    jTextField10.setText(df.format(empets));
                
                    
                }else{
                jTextField3.setText(df.format(0));
                    jTextField8.setText(df.format(0));
                    jTextField10.setText(df.format(0));
                
                
                }
                
      calculateTotalAmount();
        } catch (Exception e) {
            e.printStackTrace();
        }}
   void deductionTableLoad(){

 try {
     cleartable2();
     
            Connection con = DB.connect();
               String sdate=jTextField2.getText().split(" to ")[0];
            String edate=jTextField2.getText().split(" to ")[1];
      ResultSet r = con.createStatement().executeQuery("select Reason,SUM(PAmount) as PAmount from employee_other_payment where Emp_ID='"+jComboBox2.getSelectedItem()+"'and WP='"+"W"+"'and Tdate between'"+sdate+"'and'"+edate+"' group by Reason ");
    
 dtm = (DefaultTableModel) jTable2.getModel();
                while (r.next()) {
                Vector v = new Vector();

                v.add(r.getString("Reason"));
                v.add(df.format(Double.parseDouble(r.getString("PAmount") )));
           dtm.addRow(v);
                }
      
      calculateTotalAmountdeduction();
        } catch (Exception e) {
            e.printStackTrace();
        }}
    
    
 void calculateTotalAmount() {
DefaultTableModel dtm = (DefaultTableModel)jTable1.getModel();
     Object ob[]= new Object[2];
     int i = dtm.getRowCount();
    // System.out.println(i);
     double tot=0.0;
     for (int a = 0; a < i; a++) {
         for (int b = 0; b <= 1; b++) {
             ob[b]=dtm.getValueAt(a, b);
         }
        // System.out.println(ob[4].toString());
         tot+=Double.parseDouble(ob[1].toString());
        // System.out.println(tot);
     }

     jTextField5.setText(df.format(tot)+"");
  
   
    }
    
 void calculateTotalAmountdeduction() {
DefaultTableModel dtm = (DefaultTableModel)jTable2.getModel();
     Object ob[]= new Object[2];
     int i = dtm.getRowCount();
    // System.out.println(i);
     double tot=0.0;
     for (int a = 0; a < i; a++) {
         for (int b = 0; b <= 1; b++) {
             ob[b]=dtm.getValueAt(a, b);
         }
        // System.out.println(ob[4].toString());
         tot+=Double.parseDouble(ob[1].toString());
        // System.out.println(tot);
     }

     jTextField7.setText(df.format(tot)+"");
  
   
    }
 
       private void alignCenter(JTable table, int column) {
    DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
    rightRenderer.setHorizontalAlignment(JLabel.CENTER);
    table.getColumnModel().getColumn(column).setCellRenderer(rightRenderer);
}
         private void alignRightt(JTable table, int column) {
    DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
    rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
    table.getColumnModel().getColumn(column).setCellRenderer(rightRenderer);
}   
 
  
     void   setstart(){
         dateChooserCombo2.setEnabled(false);
         dateChooserCombo4.setEnabled(false);
         dateChooserCombo5.setEnabled(false);
         
         jTextField6.setEnabled(false);
    
     jTextField4.setEnabled(false);
    
     jComboBox2.setEnabled(false);
      
     jComboBox1.setEnabled(false);
      
     
     }
  
  
    
    void dateRange(){
      if(jRadioButton4.isSelected() ){
        
         String f1date = dateChooserCombo4.getText();
            String jdate = null;
            String arry[] = f1date.split("/");
            jdate = arry[2] + "-" + arry[0] + "-" + arry[1];
    
        String f2date = dateChooserCombo5.getText();
            String jdate1 = null;
            String arry2[] = f2date.split("/");
            jdate1 = arry2[2] + "-" + arry2[0] + "-" + arry2[1];
      
      jTextField2.setText( "20"+jdate+ " to 20"+ jdate1) ;  
     
      jComboBox2.setEnabled(true);
      jComboBox1.setEnabled(true);
      jTextField4.setEnabled(true);
      
      EID();
      EFName();
        }
        
        else{
        
        jRadioButton3.setSelected(true);
        
        String daterange= dateChooserCombo2.getText();
        String fdate[]=daterange.split(" - ");
        
        if(fdate.length==1){
            
            JOptionPane.showMessageDialog(null, "Select date range by draging between date by mouse first");
        }
        else{
        String f1date = fdate[0];
            String jdate = null;
            String arry[] = f1date.split("/");
            jdate = arry[2] + "-" + arry[0] + "-" + arry[1];
    
        String f2date = fdate[1];
            String jdate1 = null;
            String arry2[] = f2date.split("/");
            jdate1 = arry2[2] + "-" + arry2[0] + "-" + arry2[1];
        
     
          jTextField2.setText(   "20"+jdate+" to 20"+ jdate1 );  
   
      jComboBox2.setEnabled(true);
      jComboBox1.setEnabled(true);
      jTextField4.setEnabled(true);
      
      EID();
          EFName();  
        }
    
    
    
      }
    
    
    }
   public  void EID() {
        try {
            Connection con = DB.connect();
            ResultSet r = con.createStatement().executeQuery("select Emp_ID from employee where active='"+"Y"+"'");
           
           jComboBox2.removeAllItems();
            while (r.next()) {
                String b = r.getString("Emp_ID");
        
                jComboBox2.addItem(b);
                
           
            }


        } catch (Exception ex) {
            ex.printStackTrace();
        }}
   public  void EFName() {
        try {
            Connection con = DB.connect();
            ResultSet r = con.createStatement().executeQuery("select FName from employee where  active='"+"Y"+"'");
           
           jComboBox1.removeAllItems();
            while (r.next()) {
                String b = r.getString("FName");
        
                jComboBox1.addItem(b);
                
           
            }


        } catch (Exception ex) {
            ex.printStackTrace();
        }}
   public  void Empdetails() {
        try {
            Connection con = DB.connect();
            ResultSet r = con.createStatement().executeQuery("select * from employee where active='"+"Y"+"'and Emp_ID='"+jComboBox2.getSelectedItem()+"'");
           
           
            while (r.next()) { 
                jTextField6.setText(  r.getString("FName")+" "+r.getString("LName")  );
                jComboBox1.setSelectedItem(r.getString("FName")  );
                jTextField14.setText(  r.getString("emptype")  );
                jTextField15.setText(  r.getString("NIC")  );
                jTextField16.setText(  r.getString("Epsno")  );
                jTextField17.setText(  r.getString("AccNo")  );
                
               ESP= r.getString("Eps");
               // System.out.println(ESP);
            }

            String sdate=jTextField2.getText().split(" to ")[0];
            String edate=jTextField2.getText().split(" to ")[1];
            
              ResultSet r1 = con.createStatement().executeQuery("select SUM(Attend) AS sum_of_attendece from attendence where Emp_ID='"+jComboBox2.getSelectedItem()+"'and ADate between'"+sdate+"'and'"+edate+ "' " );
           
           
            while (r1.next()) { 
                jTextField4.setText(  r1.getString( "sum_of_attendece")  );
               
           
            }
            BasicTableLoad();
            deductionTableLoad();
            double perday=Double.parseDouble(jTextField5.getText())/Double.parseDouble(jTextField4.getText());
            double netSalary=Double.parseDouble(jTextField5.getText())-Double.parseDouble(jTextField7.getText())-Double.parseDouble(jTextField10.getText());
        jTextField9.setText(df.format(netSalary));
        jTextField18.setText(df.format(perday));
        jButton2.setEnabled(true);
        jButton8.setEnabled(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }}
  
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        dateChooserCombo1 = new datechooser.beans.DateChooserCombo();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jTextField6 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        dateChooserCombo2 = new datechooser.beans.DateChooserCombo();
        jLabel10 = new javax.swing.JLabel();
        dateChooserCombo4 = new datechooser.beans.DateChooserCombo();
        dateChooserCombo5 = new datechooser.beans.DateChooserCombo();
        jLabel11 = new javax.swing.JLabel();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextField5 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jTextField7 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jComboBox1 = new javax.swing.JComboBox();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jTextField13 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jTextField15 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jTextField16 = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        jTextField17 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jTextField18 = new javax.swing.JTextField();
        jButton9 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Advance and other payment to employee");
        setResizable(false);

        jLabel1.setText("Payment  no:");

        jTextField1.setEnabled(false);

        jLabel2.setText("Today:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("Employee First Name:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("Employee  Name");

        jTextField4.setEditable(false);
        jTextField4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTextField4.setForeground(new java.awt.Color(255, 51, 153));
        jTextField4.setDisabledTextColor(new java.awt.Color(0, 51, 153));
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        jTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField4KeyPressed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGE/Save-icon.png"))); // NOI18N
        jButton2.setText("Pay salary");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton6.setText("Close");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Reset all");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jTextField6.setEditable(false);
        jTextField6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTextField6.setDisabledTextColor(new java.awt.Color(0, 51, 204));
        jTextField6.setEnabled(false);
        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        jTextField6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField6KeyPressed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("Number of day attendence");

        jComboBox2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText("Pay Sheet Print");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Select months to pay sheet", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 14), new java.awt.Color(255, 51, 51))); // NOI18N

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGE/Ok-icon.png"))); // NOI18N
        jButton5.setText("Set Date Range");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Date range  :");

        jTextField2.setEditable(false);
        jTextField2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jTextField2.setText(" ");
        jTextField2.setDisabledTextColor(new java.awt.Color(255, 0, 51));
        jTextField2.setEnabled(false);

        dateChooserCombo2.setCurrentView(new datechooser.view.appearance.AppearancesList("Swing",
            new datechooser.view.appearance.ViewAppearance("custom",
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(0, 0, 0),
                    new java.awt.Color(0, 0, 255),
                    false,
                    true,
                    new datechooser.view.appearance.swing.ButtonPainter()),
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(0, 0, 0),
                    new java.awt.Color(0, 0, 255),
                    true,
                    true,
                    new datechooser.view.appearance.swing.ButtonPainter()),
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(0, 0, 255),
                    new java.awt.Color(0, 0, 255),
                    false,
                    true,
                    new datechooser.view.appearance.swing.ButtonPainter()),
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(128, 128, 128),
                    new java.awt.Color(0, 0, 255),
                    false,
                    true,
                    new datechooser.view.appearance.swing.LabelPainter()),
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(0, 0, 0),
                    new java.awt.Color(0, 0, 255),
                    false,
                    true,
                    new datechooser.view.appearance.swing.LabelPainter()),
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(0, 0, 0),
                    new java.awt.Color(255, 0, 0),
                    false,
                    false,
                    new datechooser.view.appearance.swing.ButtonPainter()),
                (datechooser.view.BackRenderer)null,
                false,
                true)));
    dateChooserCombo2.setFieldFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 12));

    jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
    jLabel10.setText("Date Range");

    jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jLabel11.setText(" To");

    buttonGroup1.add(jRadioButton3);
    jRadioButton3.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jRadioButton3ActionPerformed(evt);
        }
    });

    buttonGroup1.add(jRadioButton4);
    jRadioButton4.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jRadioButton4ActionPerformed(evt);
        }
    });

    javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
    jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(
        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel1Layout.createSequentialGroup()
            .addGap(27, 27, 27)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jLabel8)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jRadioButton3)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(dateChooserCombo2, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(jRadioButton4)
                    .addGap(18, 18, 18)
                    .addComponent(dateChooserCombo4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jLabel11)
                    .addGap(18, 18, 18)
                    .addComponent(dateChooserCombo5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGap(35, 35, 35)
            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel10)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addContainerGap())
    );
    jPanel1Layout.setVerticalGroup(
        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel1Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel8)
                    .addComponent(jRadioButton3))
                .addComponent(dateChooserCombo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(dateChooserCombo4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dateChooserCombo5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton4)))
            .addContainerGap())
    );

    jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Basic & Allownces", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 2, 12), new java.awt.Color(51, 51, 255))); // NOI18N

    jTable1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jTable1.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {

        },
        new String [] {
            "Reason", "Amount"
        }
    ) {
        boolean[] canEdit = new boolean [] {
            false, false
        };

        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return canEdit [columnIndex];
        }
    });
    jTable1.getTableHeader().setReorderingAllowed(false);
    jScrollPane1.setViewportView(jTable1);
    jTable1.getColumnModel().getColumn(0).setResizable(false);
    jTable1.getColumnModel().getColumn(0).setPreferredWidth(80);
    jTable1.getColumnModel().getColumn(1).setResizable(false);
    jTable1.getColumnModel().getColumn(1).setPreferredWidth(20);

    jTextField5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jTextField5.setDisabledTextColor(new java.awt.Color(204, 0, 102));
    jTextField5.setEnabled(false);
    jTextField5.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextField5ActionPerformed(evt);
        }
    });

    jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jLabel6.setText("Basic & Allownces Total: ");

    javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
    jPanel2.setLayout(jPanel2Layout);
    jPanel2Layout.setHorizontalGroup(
        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 526, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(124, 124, 124)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jTextField5)))
            .addContainerGap())
    );
    jPanel2Layout.setVerticalGroup(
        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel6)
                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );

    jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Salary deduction", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 2, 12), new java.awt.Color(51, 51, 255))); // NOI18N

    jTable2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jTable2.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {

        },
        new String [] {
            "Reason", "Amount"
        }
    ) {
        boolean[] canEdit = new boolean [] {
            false, false
        };

        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return canEdit [columnIndex];
        }
    });
    jTable2.getTableHeader().setReorderingAllowed(false);
    jScrollPane2.setViewportView(jTable2);
    jTable2.getColumnModel().getColumn(0).setResizable(false);
    jTable2.getColumnModel().getColumn(0).setPreferredWidth(80);
    jTable2.getColumnModel().getColumn(1).setResizable(false);
    jTable2.getColumnModel().getColumn(1).setPreferredWidth(20);

    jTextField7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jTextField7.setDisabledTextColor(new java.awt.Color(204, 0, 102));
    jTextField7.setEnabled(false);

    jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jLabel12.setText("Salary Deduction Total: ");

    javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
    jPanel3.setLayout(jPanel3Layout);
    jPanel3Layout.setHorizontalGroup(
        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel3Layout.createSequentialGroup()
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 526, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(124, 124, 124)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jTextField7)))
            .addContainerGap())
    );
    jPanel3Layout.setVerticalGroup(
        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel3Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel12)
                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );

    jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jLabel5.setText("Comany Distribution    EPF (Rs):");

    jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jLabel13.setText("ETF (Rs):");

    jTextField3.setEditable(false);
    jTextField3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jTextField3.setText(" ");

    jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jLabel14.setText("Net Salary (Rs):");

    jTextField8.setEditable(false);
    jTextField8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jTextField8.setText(" ");

    jTextField9.setEditable(false);
    jTextField9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jTextField9.setForeground(new java.awt.Color(204, 0, 0));
    jTextField9.setText(" ");

    jTable3.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {

        },
        new String [] {
            "Title 1", "Title 2"
        }
    ));
    jScrollPane4.setViewportView(jTable3);

    jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { " " }));
    jComboBox1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jComboBox1ActionPerformed(evt);
        }
    });

    jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
    jLabel15.setText("Employee ID");

    jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jLabel16.setText("Employee Distribution EPF (Rs):");

    jTextField10.setEditable(false);
    jTextField10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
    jTextField10.setText(" ");

    jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Rate"));

    jTextField13.setEditable(false);

    jTextField12.setEditable(false);

    jLabel19.setText("EMPLOYEE  EPF RATE(%):");

    jButton1.setText("Change rate");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton1ActionPerformed(evt);
        }
    });

    jLabel18.setText("COMPANY EPF RATE(%):");

    jLabel17.setText("COMPANY ETF RATE(%):");

    jTextField11.setEditable(false);

    javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
    jPanel4.setLayout(jPanel4Layout);
    jPanel4Layout.setHorizontalGroup(
        jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel4Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel17)
                .addComponent(jLabel18)
                .addComponent(jLabel19)
                .addComponent(jButton1))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                .addComponent(jTextField13)
                .addComponent(jTextField11)
                .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addContainerGap())
    );
    jPanel4Layout.setVerticalGroup(
        jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel4Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel17))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel18))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addComponent(jLabel19)
                .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(jButton1)
            .addContainerGap())
    );

    jLabel20.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
    jLabel20.setText("Employee type");

    jTextField14.setEditable(false);
    jTextField14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jTextField14.setForeground(new java.awt.Color(255, 51, 153));
    jTextField14.setDisabledTextColor(new java.awt.Color(0, 51, 153));
    jTextField14.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextField14ActionPerformed(evt);
        }
    });
    jTextField14.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyPressed(java.awt.event.KeyEvent evt) {
            jTextField14KeyPressed(evt);
        }
    });

    jButton8.setText("View report only");
    jButton8.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton8ActionPerformed(evt);
        }
    });

    jLabel21.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
    jLabel21.setText("Employee NIC");

    jTextField15.setEditable(false);
    jTextField15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jTextField15.setForeground(new java.awt.Color(255, 51, 153));
    jTextField15.setDisabledTextColor(new java.awt.Color(0, 51, 153));
    jTextField15.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextField15ActionPerformed(evt);
        }
    });
    jTextField15.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyPressed(java.awt.event.KeyEvent evt) {
            jTextField15KeyPressed(evt);
        }
    });

    jLabel22.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
    jLabel22.setText("Employee ETF/EPF No");

    jTextField16.setEditable(false);
    jTextField16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jTextField16.setForeground(new java.awt.Color(255, 51, 153));
    jTextField16.setDisabledTextColor(new java.awt.Color(0, 51, 153));
    jTextField16.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextField16ActionPerformed(evt);
        }
    });
    jTextField16.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyPressed(java.awt.event.KeyEvent evt) {
            jTextField16KeyPressed(evt);
        }
    });

    jLabel23.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
    jLabel23.setText("Bank Account No");

    jTextField17.setEditable(false);
    jTextField17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jTextField17.setForeground(new java.awt.Color(255, 51, 153));
    jTextField17.setDisabledTextColor(new java.awt.Color(0, 51, 153));
    jTextField17.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextField17ActionPerformed(evt);
        }
    });
    jTextField17.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyPressed(java.awt.event.KeyEvent evt) {
            jTextField17KeyPressed(evt);
        }
    });

    jLabel24.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
    jLabel24.setText("Salary per day( Rs )");

    jTextField18.setEditable(false);
    jTextField18.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    jTextField18.setForeground(new java.awt.Color(255, 51, 153));
    jTextField18.setDisabledTextColor(new java.awt.Color(0, 51, 153));
    jTextField18.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextField18ActionPerformed(evt);
        }
    });
    jTextField18.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyPressed(java.awt.event.KeyEvent evt) {
            jTextField18KeyPressed(evt);
        }
    });

    jButton9.setText("Quick Print only");
    jButton9.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton9ActionPerformed(evt);
        }
    });

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(35, 35, 35)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(33, 33, 33)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel13)
                                .addComponent(jLabel5))
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextField8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(62, 62, 62)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel16)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(10, 10, 10)
                                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(39, 39, 39)
                                    .addComponent(jLabel14))
                                .addGroup(layout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, 114, Short.MAX_VALUE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, 114, Short.MAX_VALUE)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(29, 29, 29)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(45, 45, 45)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGap(3, 3, 3)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addGap(288, 288, 288)
                                                            .addComponent(jLabel4))
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addGap(58, 58, 58)
                                                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 373, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addGap(10, 10, 10)
                                                            .addComponent(jLabel15)
                                                            .addGap(472, 472, 472))
                                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGroup(layout.createSequentialGroup()
                                                                    .addGap(17, 17, 17)
                                                                    .addComponent(jLabel23)))
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addGap(17, 17, 17)
                                                            .addComponent(jLabel22)))))
                                            .addGap(18, 18, 18)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGap(9, 9, 9)
                                                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 103, Short.MAX_VALUE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addGap(18, 18, 18)
                                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(67, 67, 67))))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(10, 10, 10)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGap(52, 52, 52)
                                    .addComponent(jLabel24)))
                            .addGap(59, 59, 59))))
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(503, 503, 503)
                            .addComponent(jLabel7))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(22, 22, 22)
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(dateChooserCombo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addContainerGap())
    );
    layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jLabel7)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(dateChooserCombo1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                .addGroup(layout.createSequentialGroup()
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel3)
                                .addComponent(jLabel21))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel22)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel23)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createSequentialGroup()
                    .addGap(33, 33, 33)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel4)
                                .addComponent(jLabel9)
                                .addComponent(jLabel15))
                            .addGap(4, 4, 4)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel24)
                            .addGap(4, 4, 4)
                            .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel5)
                                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jLabel16))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel13)
                                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(jButton2)
                                .addComponent(jLabel14))
                            .addContainerGap())
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jButton6)
                                .addComponent(jButton7)
                                .addComponent(jButton8)
                                .addComponent(jButton9)))))
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jLabel20)
                    .addGap(4, 4, 4)
                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))))
    );

    pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
       // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jTextField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField4KeyPressed
     if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9' ) {
             if(!(jTextField4.getText().contains("."))){
            jTextField4.setEditable(true);
             }
               
             if((jTextField4.getText().contains("."))&&(  jTextField4.getText().charAt((jTextField4.getText().length()-1) )=='.')){
               
                     jTextField4.setEditable(true);
                 
                }
             
             else  {
                 
                 if(jTextField4.getText().contains(".")&&(  jTextField4.getText().charAt((jTextField4.getText().length()-1) )!='.')){
                 
                 
             int a=jTextField4.getText().split("\\.")[1].length();
                if(a<2){
                    
                     jTextField4.setEditable(true);
                 
                }
               else{
               jTextField4.setEditable(false);
               }}
               
               
 
       
    }  
             
             
     //   jTextField4.setEditable(true);
      
    }
         
         
         
      else if(evt.getKeyChar() == '.' ){
        if(!(jTextField4.getText().contains("."))){
                           jTextField4.setEditable(true);    
         
        }else{
            jTextField4.setEditable(false);    
        }
           
    }
      
    else if(evt.getKeyCode()==KeyEvent.VK_BACK_SPACE){
        if(!jTextField4.getText().isEmpty()){
        String n =jTextField4.getText().substring(0, jTextField4.getText().length()-1); 
    jTextField4.setText(n);
    
        }
    }
     
      
    else {
        jTextField4.setEditable(false);
       
    }        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4KeyPressed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
   int c = JOptionPane.showConfirmDialog(null, "Are you sure  save save pay sheet  of employee '"+jTextField6.getText()+"' ? \nCheck wheather all are correcr before transfer", "Confirm save", JOptionPane.YES_NO_CANCEL_OPTION);
         if(c==0){
           cleartable3();
           String pno="";
           try {
                  Connection con = DB.connect();
                  ResultSet r = con.createStatement().executeQuery("select pno from paysheet where Emp_ID='"+jComboBox2.getSelectedItem()+"'and  year = '"+  Integer.parseInt(jTextField2.getText().split(" to ")[1].split("-")[0])+"'and month='"+Integer.parseInt(jTextField2.getText().split(" to ")[1].split("-")[1])+"'");
           
           boolean isvalid=true;
        
            while (r.next()) { 
                 isvalid=false;
               pno=r.getString("pno");
                       
           
            }
            
            if(isvalid){ 

 PreparedStatement p = con.prepareStatement("insert into paysheet values ('" + Integer.parseInt(jTextField1.getText())  + "','"+jComboBox2.getSelectedItem() + "','" + jTextField6.getText()  + "','" + Double.parseDouble(jTextField5.getText()) + "','" + Double.parseDouble(jTextField7.getText())+  "','" + Double.parseDouble(jTextField3.getText())+  "','" + Double.parseDouble(jTextField8.getText())+  "','" + Double.parseDouble(jTextField9.getText())+  "','" + Integer.parseInt(jTextField2.getText().split(" to ")[1].split("-")[0])+  "','" + Integer.parseInt(jTextField2.getText().split(" to ")[1].split("-")[1]) + "','" + jTextField4.getText()+ "','" + Double.parseDouble(jTextField10.getText())+ "','" + jTextField17.getText() +   "')");
                p.executeUpdate();
                p.close();
            autoGRNno();
            }
             
             else{JOptionPane.showMessageDialog(null, "This pay sheet already saved as pay sheet no'"+pno+"' \nYou can get report "  );
         }}
             catch (Exception e) {
                 e.printStackTrace();
             }
           
               
        
             dtm = (DefaultTableModel) jTable1.getModel();
             dtm2 = (DefaultTableModel) jTable3.getModel();
            //to get all Jtable sels in rows
                int b=0;
                int a =jTable1.getRowCount();
                  int k=1;
                 while (  k==1) {
                Vector v = new Vector();

                v.add("-- Basic and allowence --");
                v.add("");
              
              k++;
                
                 dtm2.addRow(v);
                }
                 
                while (b<a) {
                Vector v = new Vector();

                v.add(dtm.getValueAt(b, 0));
                v.add(dtm.getValueAt(b, 1));
              
              b++;
                
                 dtm2.addRow(v);
                }
                 int k2=1;
                 while (  k2==1) {
                Vector v = new Vector();

                v.add(" ");
                v.add(" ");
              
              k2++;
                
                 dtm2.addRow(v);
                }
                
                
        int k1=1;
                 while (  k1==1) {
                Vector v = new Vector();

                v.add("-- Salary deduction --");
                v.add("");
              
              k1--;
                
                 dtm2.addRow(v);
                }
                    
             dtm3 = (DefaultTableModel) jTable2.getModel();
             
            //to get all Jtable sels in rows
                int d=0;
                int w =jTable2.getRowCount();
              
                while (d<w) {
                Vector v = new Vector();

                v.add(dtm3.getValueAt(d, 0));
                v.add("- "+dtm3.getValueAt(d, 1));
              
              d++;
                
                 dtm2.addRow(v);
                }
                
                 int k3=1;
                 while (  k3==1) {
                Vector v = new Vector();

                v.add(" ");
                v.add( " ");
              
              k3++;
                
                 dtm2.addRow(v);
                }
            try {
                 DefaultTableModel dtm4 = (DefaultTableModel) jTable3.getModel();
            
            JRTableModelDataSource ds1= new JRTableModelDataSource(dtm4);
                   Map<String, Object> params1 = new HashMap<String, Object>();
                
            
                 
                params1.put("rdate", jTextField2.getText().split(" to ")[0]);
                params1.put("rdate1", jTextField2.getText().split(" to ")[1]);

                params1.put("name", jTextField6.getText());
                params1.put("baamount",  jTextField5.getText());
                params1.put("damount",  "- "+jTextField7.getText());
                params1.put("dets",  "- "+jTextField10.getText());
                params1.put("nsalary",  jTextField9.getText());
                params1.put("cdsi",  jTextField8.getText());
                params1.put("cdsi",  jTextField8.getText());
                params1.put("cdsi2",  jTextField3.getText());
                  
                params1.put("wd",  jTextField4.getText());
                params1.put("emptype",  jTextField14.getText());
                  params1.put("nic",  jTextField15.getText());
                params1.put("etfno",  jTextField16.getText());
                params1.put("sum",  Double.parseDouble(jTextField8.getText())+ Double.parseDouble(jTextField3.getText()));
                              double tsum= ( Double.parseDouble(jTextField8.getText())+ Double.parseDouble(jTextField3.getText())+ Double.parseDouble(jTextField10.getText()));
                params1.put("tsum",tsum);

            
                String rename = "pay_sheet.jrxml";
            //  String rename = "src//Reports//Date_range_Stock_update1.jrxml";
             
                   JasperReport jr = JasperCompileManager.compileReport(rename);
              JasperPrint jp = JasperFillManager.fillReport(jr, params1, ds1);
              
                JasperViewer jv = new JasperViewer(jp);
                jv.viewReport(jp, false);
                
                      
                  
              
                
                jButton2.setEnabled(false);
                jButton8.setEnabled(false);
        } catch (Exception e) {
            e.printStackTrace();
                  System.out.println(e.getMessage());
        }
        
        
        
        
             
             
             
             
             
             
             
             
             
             
             
             /*try {
                   Connection con = DB.connect();
    dtm = (DefaultTableModel) jTable1.getModel();
            //to get all Jtable sels in rows
            Object ob[] = new Object[5];
            int i = dtm.getRowCount();
            for (int a = 0; a < i; a++) {
                for (int b = 0; b <= 4; b++) {
                    ob[b] = dtm.getValueAt(a, b);
                }
                try {
                   
                 
 PreparedStatement p = con.prepareStatement("insert into employee_other_payment values ('" + Integer.parseInt(jTextField1.getText())  + "','"+ ob[0] + "','" + ob[1] + "','" + ob[2] + "','" + ob[3] + "','" + ob[4]+  "','" + "P"+   "')");
                p.executeUpdate();
                p.close();
        
                 
                   
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            
         } catch (Exception e) {
             }
        
          JOptionPane.showMessageDialog(null, "employee other payment sucessfully saved"); 
         autoGRNno();
        
      
        jTextField4.setText("");
       
        
         jButton2.setEnabled(false);
      
          cleartable();*/
       
         }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
this.dispose();
new salary_pay_sheet().setVisible(true);
// TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField6KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField6KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6KeyPressed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
Empdetails();  
// TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
dateRange();
 

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jRadioButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton3ActionPerformed
        dateChooserCombo4.setEnabled(false);
        dateChooserCombo5.setEnabled(false);
        dateChooserCombo2.setEnabled(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton3ActionPerformed

    private void jRadioButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton4ActionPerformed
        dateChooserCombo4.setEnabled(true);
        dateChooserCombo5.setEnabled(true);
        dateChooserCombo2.setEnabled(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton4ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
loadOthersAccName();        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
new Add_RATE().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField14ActionPerformed

    private void jTextField14KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField14KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField14KeyPressed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
     cleartable3();
     dtm = (DefaultTableModel) jTable1.getModel();
             dtm2 = (DefaultTableModel) jTable3.getModel();
            //to get all Jtable sels in rows
                int b=0;
                int a =jTable1.getRowCount();
                  int k=1;
                 while (  k==1) {
                Vector v = new Vector();

                v.add("-- Basic and allowence --");
                v.add("");
              
              k++;
                
                 dtm2.addRow(v);
                }
                 
                while (b<a) {
                Vector v = new Vector();

                v.add(dtm.getValueAt(b, 0));
                v.add(dtm.getValueAt(b, 1));
              
              b++;
                
                 dtm2.addRow(v);
                }
                 int k2=1;
                 while (  k2==1) {
                Vector v = new Vector();

                v.add(" ");
                v.add(" ");
              
              k2++;
                
                 dtm2.addRow(v);
                }
                
                
        int k1=1;
                 while (  k1==1) {
                Vector v = new Vector();

                v.add("-- Salary deduction --");
                v.add("");
              
              k1--;
                
                 dtm2.addRow(v);
                }
                    
             dtm3 = (DefaultTableModel) jTable2.getModel();
             
            //to get all Jtable sels in rows
                int d=0;
                int w =jTable2.getRowCount();
              
                while (d<w) {
                Vector v = new Vector();

                v.add(dtm3.getValueAt(d, 0));
                v.add("- "+dtm3.getValueAt(d, 1));
              
              d++;
                
                 dtm2.addRow(v);
                }
                
                 int k3=1;
                 while (  k3==1) {
                Vector v = new Vector();

                v.add(" ");
                v.add( " ");
              
              k3++;
                
                 dtm2.addRow(v);
                }   try {
                 DefaultTableModel dtm4 = (DefaultTableModel) jTable3.getModel();
            
            JRTableModelDataSource ds1= new JRTableModelDataSource(dtm4);
                   Map<String, Object> params1 = new HashMap<String, Object>();
                
            
                 
                params1.put("rdate", jTextField2.getText().split(" to ")[0]);
                params1.put("rdate1", jTextField2.getText().split(" to ")[1]);

                params1.put("name", jTextField6.getText());
                params1.put("baamount",  jTextField5.getText());
                params1.put("damount", "- "+ jTextField7.getText());
                params1.put("dets",  "- "+jTextField10.getText());
                params1.put("nsalary",  jTextField9.getText());
                params1.put("cdsi",  jTextField8.getText());
                params1.put("cdsi",  jTextField8.getText());
                params1.put("cdsi2",  jTextField3.getText());
                  
                params1.put("wd",  jTextField4.getText());
                params1.put("emptype",  jTextField14.getText());
                params1.put("nic",  jTextField15.getText());
                params1.put("etfno",  jTextField16.getText());
                params1.put("sum",  Double.parseDouble(jTextField8.getText())+ Double.parseDouble(jTextField3.getText()));
                
                double tsum= ( Double.parseDouble(jTextField8.getText())+ Double.parseDouble(jTextField3.getText())+ Double.parseDouble(jTextField10.getText()));
                params1.put("tsum",tsum);
                  
                   
           
            
                String rename = "pay_sheet.jrxml";
            //  String rename = "src//Reports//Date_range_Stock_update1.jrxml";
             
                   JasperReport jr = JasperCompileManager.compileReport(rename);
              JasperPrint jp = JasperFillManager.fillReport(jr, params1, ds1);
              
                JasperViewer jv = new JasperViewer(jp);
                jv.viewReport(jp, false);
                
                      
                  
              
                
                jButton2.setEnabled(false);
                jButton8.setEnabled(false);
        } catch (Exception e) {
            e.printStackTrace();
                  System.out.println(e.getMessage());
        }
        
                // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jTextField15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField15ActionPerformed

    private void jTextField15KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField15KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField15KeyPressed

    private void jTextField16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField16ActionPerformed

    private void jTextField16KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField16KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField16KeyPressed

    private void jTextField17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField17ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField17ActionPerformed

    private void jTextField17KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField17KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField17KeyPressed

    private void jTextField18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField18ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField18ActionPerformed

    private void jTextField18KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField18KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField18KeyPressed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
 cleartable3();
     dtm = (DefaultTableModel) jTable1.getModel();
             dtm2 = (DefaultTableModel) jTable3.getModel();
            //to get all Jtable sels in rows
                int b=0;
                int a =jTable1.getRowCount();
                  int k=1;
                 while (  k==1) {
                Vector v = new Vector();

                v.add("-- Basic and allowence --");
                v.add("");
              
              k++;
                
                 dtm2.addRow(v);
                }
                 
                while (b<a) {
                Vector v = new Vector();

                v.add(dtm.getValueAt(b, 0));
                v.add(dtm.getValueAt(b, 1));
              
              b++;
                
                 dtm2.addRow(v);
                }
                 int k2=1;
                 while (  k2==1) {
                Vector v = new Vector();

                v.add(" ");
                v.add(" ");
              
              k2++;
                
                 dtm2.addRow(v);
                }
                
                
        int k1=1;
                 while (  k1==1) {
                Vector v = new Vector();

                v.add("-- Salary deduction --");
                v.add("");
              
              k1--;
                
                 dtm2.addRow(v);
                }
                    
             dtm3 = (DefaultTableModel) jTable2.getModel();
             
            //to get all Jtable sels in rows
                int d=0;
                int w =jTable2.getRowCount();
              
                while (d<w) {
                Vector v = new Vector();

                v.add(dtm3.getValueAt(d, 0));
                v.add("- "+dtm3.getValueAt(d, 1));
              
              d++;
                
                 dtm2.addRow(v);
                }
                
                 int k3=1;
                 while (  k3==1) {
                Vector v = new Vector();

                v.add(" ");
                v.add( " ");
              
              k3++;
                
                 dtm2.addRow(v);
                }   try {
                 DefaultTableModel dtm4 = (DefaultTableModel) jTable3.getModel();
            
            JRTableModelDataSource ds1= new JRTableModelDataSource(dtm4);
                   Map<String, Object> params1 = new HashMap<String, Object>();
                
            
                 
                params1.put("rdate", jTextField2.getText().split(" to ")[0]);
                params1.put("rdate1", jTextField2.getText().split(" to ")[1]);

                params1.put("name", jTextField6.getText());
                params1.put("baamount",  jTextField5.getText());
                params1.put("damount", "- "+ jTextField7.getText());
                params1.put("dets",  "- "+jTextField10.getText());
                params1.put("nsalary",  jTextField9.getText());
                params1.put("cdsi",  jTextField8.getText());
                params1.put("cdsi",  jTextField8.getText());
                params1.put("cdsi2",  jTextField3.getText());
                  
                params1.put("wd",  jTextField4.getText());
                params1.put("emptype",  jTextField14.getText());
                params1.put("nic",  jTextField15.getText());
                params1.put("etfno",  jTextField16.getText());
                params1.put("sum",  Double.parseDouble(jTextField8.getText())+ Double.parseDouble(jTextField3.getText()));
                
                double tsum= ( Double.parseDouble(jTextField8.getText())+ Double.parseDouble(jTextField3.getText())+ Double.parseDouble(jTextField10.getText()));
                params1.put("tsum",tsum);
                  
                   
           
            
                String rename = "pay_sheet.jrxml";
            //  String rename = "src//Reports//Date_range_Stock_update1.jrxml";
             
                   JasperReport jr = JasperCompileManager.compileReport(rename);
              JasperPrint jp = JasperFillManager.fillReport(jr, params1, ds1);
              JasperPrintManager.printReport(jp, false);
          //      JasperViewer jv = new JasperViewer(jp);
            //    jv.viewReport(jp, false);
                
                      
                  
              
                
                jButton2.setEnabled(false);
                jButton8.setEnabled(false);
        } catch (Exception e) {
            System.out.println("Error while quick print "+e);
            e.printStackTrace();
                  System.out.println(e.getMessage());
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(salary_pay_sheet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(salary_pay_sheet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(salary_pay_sheet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(salary_pay_sheet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

                new salary_pay_sheet().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private datechooser.beans.DateChooserCombo dateChooserCombo1;
    private datechooser.beans.DateChooserCombo dateChooserCombo2;
    private datechooser.beans.DateChooserCombo dateChooserCombo4;
    private datechooser.beans.DateChooserCombo dateChooserCombo5;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private static javax.swing.JTextField jTextField11;
    private static javax.swing.JTextField jTextField12;
    private static javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables

   
 
  void cleartable(){
       DefaultTableModel dtm = (DefaultTableModel) jTable1.getModel();
        int i = dtm.getRowCount();

        for (int a = 0; a < i; a++) {
        }
        while (i > 0) {
            dtm.removeRow(i - 1);

            i--;   
    }
    
    } 

  void cleartable2(){
       DefaultTableModel dtm = (DefaultTableModel) jTable2.getModel();
        int i = dtm.getRowCount();

        for (int a = 0; a < i; a++) {
        }
        while (i > 0) {
            dtm.removeRow(i - 1);

            i--;   
    }
    
    } 
  void cleartable3(){
       DefaultTableModel dtm = (DefaultTableModel) jTable3.getModel();
        int i = dtm.getRowCount();

        for (int a = 0; a < i; a++) {
        }
        while (i > 0) {
            dtm.removeRow(i - 1);

            i--;   
    }
    
    } 
  
    private void autoGRNno() {
        try {
            Connection con = DB.connect();
            ResultSet r = con.createStatement().executeQuery("select pno from paysheet ");
            boolean b = false;
            String TypeID=null;
            while (r.next()) {
                TypeID = r.getString("pno");
                b= true;
            
            }
            if (b) {
                jTextField1.setText( Integer.parseInt(TypeID) + 1+""  );
            }
            else{
            jTextField1.setText( 1+"" );
            }
            
            
        } catch (Exception e) {
            e.printStackTrace();
        };
    }

    private void loadOthersAccName() {
          try {
            Connection con = DB.connect();
            ResultSet r = con.createStatement().executeQuery("select * from employee where FName='"+jComboBox1.getSelectedItem()+"'");
           
           
            while (r.next()) { 
              
                jComboBox2.setSelectedItem(r.getString("Emp_ID")  );
               
            }
            Empdetails();

       
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
  
}
