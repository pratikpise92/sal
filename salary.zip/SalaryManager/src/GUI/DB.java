/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author hp
 */
public class DB {
   
      private static Connection con;
   public static Connection connect() throws Exception{
    Class.forName("com.mysql.jdbc.Driver").newInstance();
    String url = "jdbc:mysql://localhost:3306/salary_manager";
  
    con=DriverManager.getConnection(url,"root","root");
         
        return con;
        }
    
}
    